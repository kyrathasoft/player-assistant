<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit(1);
}

require_once __DIR__ . '/BrokerHttpException.php';
require_once __DIR__ . '/WordCountService.php';
require_once __DIR__ . '/BrokerAlertService.php';
require_once __DIR__ . '/BrokerOperations.php';

try {
    $configPath = $argv[1] ?? (__DIR__ . '/config.php');
    if (!is_string($configPath) || !is_file($configPath)) {
        throw new RuntimeException('The broker configuration file was not found.');
    }

    $config = require $configPath;
    if (!is_array($config)) {
        throw new RuntimeException('The broker configuration is invalid.');
    }

    $databasePath = (string)($config['api']['database_path'] ?? '');
    if ($databasePath === '') {
        throw new RuntimeException('The broker database path is not configured.');
    }

    $operations = new BrokerOperations($config);

    $database = new PDO('sqlite:' . $databasePath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $database->exec('PRAGMA busy_timeout = 5000');
    $alerts = new BrokerAlertService(
        $database,
        is_array($config['observability'] ?? null) ? $config['observability'] : []);

    $service = new WordCountService(
        $database,
        is_array($config['word_counts'] ?? null) ? $config['word_counts'] : []);
    $snapshot = $service->refreshNow();
    $refreshStatus = $service->refreshStatus();
    if ($refreshStatus['healthy'] === false) {
        $alerts->recordRefreshFailure(
            (string)$refreshStatus['last_error_code'],
            'The scheduled word-count refresh reported a failure.');
        $service->recordSchedulerRun(false, (string)$refreshStatus['last_error_code']);
        throw new RuntimeException(
            'The latest source-backed refresh attempt failed: '
            . (string)$refreshStatus['last_error_code']);
    }
    $service->recordSchedulerRun(true);
    $operations->recordRefreshSuccess();

    echo json_encode([
        'status' => 'ok',
        'observed_at' => $snapshot['observed_at'],
        'uploaded_at' => $snapshot['uploaded_at'],
        'refresh' => $service->refreshStatus(),
    ], JSON_UNESCAPED_SLASHES) . PHP_EOL;
} catch (Throwable $error) {
    if (isset($alerts) && $alerts instanceof BrokerAlertService) {
        $alerts->recordRefreshFailure('scheduler_failed', $error->getMessage());
    }
    if (isset($service) && $service instanceof WordCountService) {
        $service->recordSchedulerRun(false, 'scheduler_failed');
    }
    if (isset($operations) && $operations instanceof BrokerOperations) {
        $operations->recordRefreshFailure(
            isset($refreshStatus) && is_array($refreshStatus)
                ? (string)($refreshStatus['last_error_code'] ?? 'scheduler_failed')
                : 'scheduler_failed');
    }
    fwrite(STDERR, 'Word-count refresh failed: ' . $error->getMessage() . PHP_EOL);
    exit(1);
}
