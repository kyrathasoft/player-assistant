# Scarlet Horizons broker and PWA recovery

Archive date: 2026-07-27

## What this archive contains

- `pwa/`: the complete deployable progressive web app, including Apache rules, icons, dictionaries, campaign-search data, hero tokens, build scripts, and verification scripts.
- `web-deploy/bryanmiller.us/scarlethorizons/api/`: the public PHP API entry point and Apache rules.
- `web-deploy/player-assistant-broker/`: all private PHP broker source files and configuration examples.
- `web-deploy/tests/`: broker security and routing tests.
- `web-deploy/*.ps1` and deployment notes: account import, word-count publishing, and operational guidance.
- `private-state/config.template.php`: a complete redacted starting configuration.
- `SHA256SUMS.txt`: SHA-256 checksums for every archived file except the checksum file itself.

This archive deliberately contains no production secrets, live `config.php`, live
`broker.sqlite`, PHP sessions, RPOL snapshots, or password-hash export. Those
items were not present in the local deployment tree and should never be stored
in an unencrypted source archive.

## First response after a compromise

1. Take the compromised site and API offline. Preserve server logs separately if
   they may be needed for investigation.
2. Do not reuse files, database state, sessions, or secrets copied from the
   compromised host unless they have been independently verified.
3. Reset the DreamHost account, SSH/SFTP, control-panel, and database credentials.
4. Rotate the broker administrator key, snapshot-signing key, RPOL password, and
   every issued bearer token. Invalidate PHP sessions and require character
   password resets if the private broker directory may have been exposed.
5. Restore to a clean hosting account or a freshly provisioned, fully patched
   account. Require HTTPS before making the application public.

## Verify this archive

From the extracted archive directory in PowerShell:

```powershell
$expected = Get-Content .\SHA256SUMS.txt
foreach ($line in $expected) {
    $hash, $relative = $line -split '  ', 2
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $relative).Hash -ne $hash) {
        throw "Checksum failed: $relative"
    }
}
```

Stop if any checksum fails.

## Restore the private broker first

The intended DreamHost layout is:

```text
/home/DREAMHOST_USER/
|-- bryanmiller.us/
|   `-- scarlethorizons/
|       |-- api/
|       `-- pwa/
`-- player-assistant-broker/
```

1. Confirm PHP has `curl`, `dom`, and `pdo_sqlite`.
2. Upload these files to `/home/DREAMHOST_USER/player-assistant-broker/`:

```text
BrokerHttpException.php
BrokerService.php
CharacterAuthService.php
RpolClient.php
WordCountService.php
XpTrackingService.php
```

3. Copy `private-state/config.template.php` to
   `/home/DREAMHOST_USER/player-assistant-broker/config.php`.
4. Replace every `CHANGE_ME` value. Generate new keys on the clean server:

```bash
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
```

   Use the first output for `admin_key` and the second for
   `snapshot_signing_key`. Update the trusted Windows snapshot publisher with the
   same new signing key. Enter the fixed private XP source URL and new RPOL
   credential values without placing them in shell history, email, chat, or logs.
5. Create empty private directories for snapshots and PHP sessions if the host
   does not create them automatically. Never place them under `bryanmiller.us/`.
6. Prefer a new database after a compromise. Set `database_path` to
   `/home/DREAMHOST_USER/player-assistant-broker/broker.sqlite`; the broker
   creates its SQLite schema on first request. Restore a known-clean offline
   `broker.sqlite` only when continuity of accounts is essential and its backup
   predates the compromise.
7. Set permissions:

```bash
chmod 700 /home/DREAMHOST_USER/player-assistant-broker
chmod 600 /home/DREAMHOST_USER/player-assistant-broker/*.php
chmod 600 /home/DREAMHOST_USER/player-assistant-broker/broker.sqlite
```

8. Configure PHP sessions outside the web root and disable production error
   display. Ensure the website's PHP process can read/write only the private
   database, snapshot, and session locations it needs.

## Restore the public API

Upload, preserving the `.htaccess` filename:

```text
web-deploy/bryanmiller.us/scarlethorizons/api/index.php
    -> /home/DREAMHOST_USER/bryanmiller.us/scarlethorizons/api/index.php

web-deploy/bryanmiller.us/scarlethorizons/api/.htaccess
    -> /home/DREAMHOST_USER/bryanmiller.us/scarlethorizons/api/.htaccess
```

Confirm `.htaccess` files are visible in the SFTP client. The public API
directory must not contain `config.php`, `broker.sqlite`, password hashes,
sessions, or snapshots.

Check:

```text
https://bryanmiller.us/scarlethorizons/api/v1/health
```

The response must be HTTP 200 with `status: "ok"` and schema version `4`.
Confirm `snapshot_signing_configured` and `xp_tracking_configured` are true.

## Recreate private application state

- If a known-clean database was not restored, recreate character accounts with
  the administrator API and fresh passwords. If a trusted offline
  `xp-passwords.json` exists, use `web-deploy/import-character-accounts.ps1`;
  never upload that file into the website tree.
- Reissue only the bearer tokens still required by trusted clients.
- Republish RPOL snapshots from the trusted Windows publisher using the rotated
  signing key.
- Republish the latest validated word-count snapshot with
  `web-deploy/publish-word-counts.ps1`.
- Log in as one player and the Dungeon Master, then verify authorization,
  current XP, word counts, presence, and logout.

## Restore the PWA

1. Upload the complete contents of `pwa/` to:

```text
/home/DREAMHOST_USER/bryanmiller.us/scarlethorizons/pwa/
```

2. Preserve all subdirectories and the PWA `.htaccess`.
3. If rebuilding from source instead of deploying this snapshot, refresh the
   public campaign search and hero tokens, run `pwa/build-data.ps1`, increment
   `CACHE_VERSION` in `service-worker.js`, and run `pwa/verify-pwa.ps1`.
4. Run the live comparison from the repository or extracted archive:

```powershell
.\pwa\test-deployment.ps1 -RequireCurrentXpApi
```

5. Open the site in a private browser window. Verify installation, offline shell,
   both translators, campaign search, dice, login, XP, word counts, presence,
   and logout. Existing clients may need one reload for the new service worker
   to take control.

## Final security checks

- HTTPS redirects are enforced and HSTS is present.
- API responses use `Cache-Control: no-store`; service-worker and manifest use
  revalidation.
- `config.php`, SQLite, snapshots, sessions, password hashes, and logs have no
  public URL.
- No old administrator key, signing key, RPOL password, bearer token, session,
  or character password remains valid.
- A clean deployment test reports matching PWA files and safe anonymous API
  behavior.

