param(
    [Parameter(Mandatory = $true)][string]$PhpPath
)

$ErrorActionPreference = 'Stop'

function Assert-Condition {
    param(
        [Parameter(Mandatory = $true)][bool]$Condition,
        [Parameter(Mandatory = $true)][string]$Message
    )
    if (!$Condition) {
        throw $Message
    }
}

$resolvedPhpPath = (Resolve-Path -LiteralPath $PhpPath).Path
$phpRoot = Split-Path -Parent $resolvedPhpPath
$repositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$documentRoot = Join-Path $repositoryRoot 'web-deploy\bryanmiller.us'
$routerPath = Join-Path $repositoryRoot 'web-deploy\tests\http-router.php'
$configPath = Join-Path $repositoryRoot 'web-deploy\tests\http-config.php'
$temporaryRoot = Join-Path $env:TEMP "player-assistant-http-auth-$([guid]::NewGuid().ToString('N'))"
$databasePath = Join-Path $temporaryRoot 'broker.sqlite'
$snapshotPath = Join-Path $temporaryRoot 'snapshots'
New-Item -ItemType Directory -Path $temporaryRoot, $snapshotPath -Force | Out-Null

$listener = [System.Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
$listener.Start()
$port = ([Net.IPEndPoint]$listener.LocalEndpoint).Port
$listener.Stop()
$baseUrl = "http://127.0.0.1:$port/scarlethorizons/api"

$previousConfig = $env:PLAYER_ASSISTANT_BROKER_CONFIG
$previousDatabase = $env:PLAYER_ASSISTANT_TEST_DATABASE
$previousSnapshots = $env:PLAYER_ASSISTANT_TEST_SNAPSHOTS
$env:PLAYER_ASSISTANT_BROKER_CONFIG = $configPath
$env:PLAYER_ASSISTANT_TEST_DATABASE = $databasePath
$env:PLAYER_ASSISTANT_TEST_SNAPSHOTS = $snapshotPath

$process = $null
try {
    $process = Start-Process `
        -FilePath $resolvedPhpPath `
        -ArgumentList @(
            '-n',
            '-d', "extension_dir=$(Join-Path $phpRoot 'ext')",
            '-d', 'extension=pdo_sqlite',
            '-d', 'extension=curl',
            '-S', "127.0.0.1:$port",
            '-t', $documentRoot,
            $routerPath
        ) `
        -WindowStyle Hidden `
        -PassThru

    $health = $null
    for ($attempt = 0; $attempt -lt 30 -and $null -eq $health; $attempt++) {
        try {
            $health = Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl/v1/health"
        }
        catch {
            Start-Sleep -Milliseconds 100
        }
    }
    Assert-Condition -Condition ($null -ne $health -and $health.StatusCode -eq 200) -Message 'The HTTP test broker did not start.'
    Assert-Condition -Condition ($health.Headers['Cache-Control'] -contains 'no-store') -Message 'The API response was cacheable.'
    Assert-Condition -Condition ($health.Headers['Strict-Transport-Security'] -contains 'max-age=31536000') -Message 'The HSTS header was missing.'

    $unauthenticatedXp = Invoke-WebRequest `
        -UseBasicParsing `
        -SkipHttpErrorCheck `
        -Uri "$baseUrl/v1/xp"
    Assert-Condition -Condition ($unauthenticatedXp.StatusCode -eq 401) -Message 'The HTTP XP route was not session-protected.'
    Assert-Condition -Condition ([string]$unauthenticatedXp.Headers['Cache-Control'] -match '(?i)(^|,\s*)no-store($|,)') -Message 'The rejected XP response was cacheable.'

    $adminHeaders = @{ 'X-Broker-Admin-Key' = 'http-test-administrator-key' }
    $createResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Method Post `
        -Uri "$baseUrl/v1/admin/character-accounts" `
        -Headers $adminHeaders `
        -ContentType 'application/json' `
        -Body (@{
            character_name = 'HTTP Hero'
            password = 'http integration password'
            character_key = 'http-hero'
            role = 'player'
        } | ConvertTo-Json -Compress)
    Assert-Condition -Condition ($createResponse.StatusCode -eq 201) -Message 'The HTTP account creation route failed.'

    $loginResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Method Post `
        -Uri "$baseUrl/v1/login" `
        -Headers @{ Origin = 'https://example.test' } `
        -ContentType 'application/json' `
        -Body (@{
            character_name = 'HTTP Hero'
            password = 'http integration password'
        } | ConvertTo-Json -Compress)
    $loginBody = $loginResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($loginBody.authenticated -eq $true) -Message 'The HTTP character login failed.'
    $setCookie = [string]$loginResponse.Headers['Set-Cookie']
    Assert-Condition -Condition ($setCookie -match 'pa_character_session=') -Message 'The character session cookie was not issued.'
    Assert-Condition -Condition ($setCookie -match '(?i);\s*Secure') -Message 'The character session cookie was not Secure.'
    Assert-Condition -Condition ($setCookie -match '(?i);\s*HttpOnly') -Message 'The character session cookie was not HttpOnly.'
    Assert-Condition -Condition ($setCookie -match '(?i);\s*SameSite=Strict') -Message 'The character session cookie was not SameSite=Strict.'
    Assert-Condition -Condition ($setCookie -match '(?i);\s*path=/scarlethorizons/api/') -Message 'The character session cookie path was too broad.'
    $cookieHeader = $setCookie.Split(';')[0]

    $sessionResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Uri "$baseUrl/v1/session" `
        -Headers @{ Cookie = $cookieHeader }
    $sessionBody = $sessionResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($sessionBody.authenticated -eq $true) -Message 'The HTTP session was not restored.'

    $identityResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Uri "$baseUrl/v1/me" `
        -Headers @{ Cookie = $cookieHeader }
    $identity = $identityResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($identity.account.character_key -eq 'http-hero') -Message 'The protected identity was not session-authorized.'

    $unconfiguredXp = Invoke-WebRequest `
        -UseBasicParsing `
        -SkipHttpErrorCheck `
        -Uri "$baseUrl/v1/xp" `
        -Headers @{ Cookie = $cookieHeader }
    $unconfiguredXpBody = $unconfiguredXp.Content | ConvertFrom-Json
    Assert-Condition -Condition ($unconfiguredXp.StatusCode -eq 503) -Message 'The unconfigured HTTP XP route did not fail closed.'
    Assert-Condition -Condition ($unconfiguredXpBody.error -eq 'xp_unavailable') -Message 'The unconfigured HTTP XP route returned the wrong error.'
    Assert-Condition -Condition ($unconfiguredXp.Content -notmatch 'publish\.obsidian\.md') -Message 'The HTTP XP error exposed its source URL.'

    $unauthenticatedWordCounts = Invoke-WebRequest `
        -UseBasicParsing `
        -SkipHttpErrorCheck `
        -Uri "$baseUrl/v1/word-counts"
    Assert-Condition -Condition ($unauthenticatedWordCounts.StatusCode -eq 401) -Message 'The HTTP word-count route was not session-protected.'

    $unauthenticatedPresence = Invoke-WebRequest `
        -UseBasicParsing `
        -SkipHttpErrorCheck `
        -Uri "$baseUrl/v1/presence"
    Assert-Condition -Condition ($unauthenticatedPresence.StatusCode -eq 401) -Message 'The HTTP presence route was not session-protected.'

    $observedAt = [DateTimeOffset]::UtcNow.ToString('o')
    $wordCountUpload = Invoke-WebRequest `
        -UseBasicParsing `
        -Method Put `
        -Uri "$baseUrl/v1/admin/word-counts" `
        -Headers $adminHeaders `
        -ContentType 'application/json' `
        -Body (@{
            schema_version = 1
            observed_at = $observedAt
            counting_rule_version = 'obsidian-publish-word-count-v1'
            wiki = @{ pages = 985; words = 232048 }
            ic = @{ files = 8; words = 14998 }
            ooc = @{ files = 6; words = 18652 }
        } | ConvertTo-Json -Depth 4 -Compress)
    Assert-Condition -Condition ($wordCountUpload.StatusCode -eq 201) -Message 'The HTTP word-count upload failed.'

    $wordCountResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Uri "$baseUrl/v1/word-counts" `
        -Headers @{ Cookie = $cookieHeader }
    $wordCountBody = $wordCountResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($wordCountResponse.StatusCode -eq 200) -Message 'The HTTP word-count read failed.'
    Assert-Condition -Condition ([DateTimeOffset]$wordCountBody.observed_at -eq [DateTimeOffset]$observedAt) -Message 'The HTTP word-count observation time changed.'
    Assert-Condition -Condition ([long]$wordCountBody.wiki.words -eq 232048) -Message 'The HTTP wiki word count was incorrect.'
    Assert-Condition -Condition ([long]$wordCountBody.ic.words -eq 14998) -Message 'The HTTP IC word count was incorrect.'
    Assert-Condition -Condition ([long]$wordCountBody.ooc.words -eq 18652) -Message 'The HTTP OOC word count was incorrect.'
    Assert-Condition -Condition ([string]$wordCountResponse.Headers['Cache-Control'] -match '(?i)(^|,\s*)no-store($|,)') -Message 'Word-count responses must use Cache-Control: no-store.'

    $presenceResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Uri "$baseUrl/v1/presence" `
        -Headers @{ Cookie = $cookieHeader }
    $presenceBody = $presenceResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($presenceResponse.StatusCode -eq 200) -Message 'The HTTP presence route failed.'
    Assert-Condition -Condition ($presenceBody.scope -eq 'self' -and @($presenceBody.users).Count -eq 0) -Message 'A player presence response exposed other users.'
    Assert-Condition -Condition ([string]$presenceResponse.Headers['Cache-Control'] -match '(?i)(^|,\s*)no-store($|,)') -Message 'Presence responses must use Cache-Control: no-store.'

    $logoutResponse = Invoke-WebRequest `
        -UseBasicParsing `
        -Method Post `
        -Uri "$baseUrl/v1/logout" `
        -Headers @{
            Cookie = $cookieHeader
            Origin = 'https://example.test'
            'X-CSRF-Token' = [string]$sessionBody.csrf_token
        } `
        -ContentType 'application/json' `
        -Body '{}'
    $logoutBody = $logoutResponse.Content | ConvertFrom-Json
    Assert-Condition -Condition ($logoutBody.authenticated -eq $false) -Message 'The HTTP logout failed.'

    Write-Output 'HTTP character authentication tests passed.'
}
finally {
    if ($process -and !$process.HasExited) {
        Stop-Process -Id $process.Id
    }
    $env:PLAYER_ASSISTANT_BROKER_CONFIG = $previousConfig
    $env:PLAYER_ASSISTANT_TEST_DATABASE = $previousDatabase
    $env:PLAYER_ASSISTANT_TEST_SNAPSHOTS = $previousSnapshots
    $resolvedTemporaryRoot = [IO.Path]::GetFullPath($temporaryRoot)
    $resolvedSystemTemp = [IO.Path]::GetFullPath($env:TEMP).TrimEnd('\') + '\'
    if ($resolvedTemporaryRoot.StartsWith($resolvedSystemTemp, [StringComparison]::OrdinalIgnoreCase) -and
        (Split-Path -Leaf $resolvedTemporaryRoot) -like 'player-assistant-http-auth-*') {
        Remove-Item -LiteralPath $resolvedTemporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
