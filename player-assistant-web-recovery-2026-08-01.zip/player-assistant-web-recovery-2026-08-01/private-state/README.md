# Private state not included

This directory contains only a redacted configuration template.

The archive does not contain production `config.php`, `broker.sqlite`, RPOL
snapshots, PHP sessions, bearer tokens, administrator/signing keys, RPOL
credentials, or character password hashes. Recreate or restore those items only
from a trusted encrypted offline backup, and rotate all secrets after a website
compromise.
