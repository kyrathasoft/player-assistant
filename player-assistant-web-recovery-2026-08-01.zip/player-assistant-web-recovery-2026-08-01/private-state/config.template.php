<?php

declare(strict_types=1);

/*
 * Copy to /home/DREAMHOST_USER/player-assistant-broker/config.php.
 * Replace every CHANGE_ME value on the clean server. Keep this file, the
 * database, snapshots, and PHP sessions outside the website document root.
 */
return [
    'api' => [
        'base_path' => '/scarlethorizons/api',
        'database_path' => '/home/CHANGE_ME_DREAMHOST_USER/player-assistant-broker/broker.sqlite',
        'admin_key' => 'CHANGE_ME_NEW_RANDOM_64_HEX_CHARACTERS',
        'default_token_lifetime_days' => 30,
        'max_token_lifetime_days' => 365,
        'requests_per_minute' => 60,
        'snapshot_directory' => '/home/CHANGE_ME_DREAMHOST_USER/player-assistant-broker/snapshots',
        'snapshot_signing_key' => 'CHANGE_ME_NEW_BASE64_32_BYTE_KEY',
        'snapshot_max_age_seconds' => 86400,
        'snapshot_retention_seconds' => 604800,
    ],
    'auth' => [
        'expected_origin' => 'https://bryanmiller.us',
        'cookie_path' => '/scarlethorizons/api/',
        'idle_timeout_seconds' => 1800,
        'absolute_timeout_seconds' => 28800,
        'login_window_seconds' => 900,
        'login_max_failures' => 5,
        'login_lockout_seconds' => 900,
    ],
    'rpol' => [
        'username' => 'CHANGE_ME_RPOL_USERNAME',
        'password' => 'CHANGE_ME_RPOL_PASSWORD',
        'game_id' => '80170',
        'initial_url' => 'https://rpol.net/',
        'connect_timeout_seconds' => 5,
        'request_timeout_seconds' => 20,
        'max_response_bytes' => 5242880,
        'user_agent' => 'PlayerAssistantBroker/1.0',
    ],
    'xp' => [
        'source_url' => 'CHANGE_ME_PRIVATE_HTTPS_XP_MARKDOWN_URL',
        'character_source_url' => 'https://publish.obsidian.md/scarlethorizons/PCs/Player+Characters+Listing',
        'class_progression_index_url' => 'https://publish.obsidian.md/scarlethorizons/Classes/Class+Level+Progression',
        'connect_timeout_seconds' => 3,
        'timeout_seconds' => 8,
        'maximum_response_bytes' => 524288,
        'cache_ttl_seconds' => 300,
        'maximum_stale_seconds' => 86400,
    ],
];

