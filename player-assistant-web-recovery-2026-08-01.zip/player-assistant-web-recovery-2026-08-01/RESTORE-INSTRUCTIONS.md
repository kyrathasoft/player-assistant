# Player Assistant web recovery archive — 2026-08-01

This archive contains the complete deployable PWA source and generated runtime
assets, plus the non-secret PHP broker/API deployment files needed for character
login and protected PWA features.

## Restore

1. Copy `pwa/` to the web host's Scarlet Horizons PWA directory, preserving all subdirectories and files.
2. Deploy `web-deploy/bryanmiller.us/scarlethorizons/api/` to the public API path.
3. Deploy the PHP files under `web-deploy/player-assistant-broker/` to the private broker directory.
4. Recreate the excluded private files from secure backup: `player-assistant-broker/config.php` and `player-assistant-broker/broker.sqlite`.
5. Merge the example auth/XP settings into the private configuration, then import character accounts as described in `web-deploy/CHARACTER-AUTH-DEPLOY.md`.
6. Verify the PWA with `pwa/verify-pwa.ps1` and run deployment tests after the HTTPS API and broker are available.

The archive intentionally excludes live configuration, account/session data,
password hashes, and the broker database. Do not place those files under the
public document root.

Archive date: 2026-08-01
